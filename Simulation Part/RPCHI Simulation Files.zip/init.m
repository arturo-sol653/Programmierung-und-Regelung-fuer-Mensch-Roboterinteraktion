eg = [0 1 0];

% Robot parameters
m1 = 3; % Mass link 1 
m2 = 3; % Mass link 2
m3 = 3; % Mass link 3
l1 = 1/3; % Lenght link 1
l2 = 1/3; % Lenght link 2
l3 = 1/3; % Lenght link 3
mx1 = m1*l1/2 ; % Mass moment first order 1
mx2 = m2*l2/2 ; % Mass moment first order 2
mx3 = m3*l3/2 ; % Mass moment first order 3
I1 = 4/12*m1*l1^2; %Mass moment of Inertia 1
I2 = 4/12*m2*l2^2; %Mass moment of Inertia 2
I3 = 4/12*m3*l3^2; %Mass moment of Inertia 3

%Q_0
q1_0= deg2rad(0);
q2_0= deg2rad(90);
q3_0= deg2rad(0);
q_0 = [q1_0 q2_0 q3_0];

q_0_dot= [0 0 0];
T= [0 0 0];

%Q_desire0
q1_d= deg2rad(0);
q2_d= deg2rad(0);
q3_d= deg2rad(0);
q_d = [q1_d q2_d q3_d];

K_f=1;
K_p=diag([15,15,15]);
K_d=diag([4,4,4]);
zeta=1;
%K_d=diag([10,10,10]);
%K_d= 2*0.5*sqrtm(K_p/M);
% Library
addpath('3DOF_library');


%Translational Control
K_t=diag([50 50]);
D_t=diag([5,5]);
x_d= 0;
y_d= 1;
cartesian_d=[x_d y_d ];

%Colision Detection
%K_col=diag([0.05,0.05,0.05]);
%K_col=diag([1,1,1]);
K_col=diag([0.2,0.2,0.2]);

%Nullspace Optimization
I=diag([1,1,1]);
D_nullspace=diag([5,5,5]);
%D_nullspace=diag([10,10,10]);

%Singularity Avoidance
K_s=10;

mmax_percentage = 1 ;